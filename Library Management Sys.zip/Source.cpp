#include<iostream>
#include<conio.h>
#include<string>
#include<fstream>
#include"book.h"
using namespace std;

typedef book* bookPtr;

void getline(istream& stream, string& str, char delimiter)
{
    char temp[500];

    stream.get(temp, 500, delimiter);
    stream.ignore(500, delimiter);
    str = temp;
}

void getline(istream& stream, int& num, char delimiter)
{
    int temp;

    stream >> temp;
    stream.ignore(500, delimiter);
    num = temp;
}

void readFile(bookPtr& root);
void insert(bookPtr& root);
void delTitle(bookPtr& root);
bookPtr locateNode(bookPtr temp, string titl);
void delIsbn(bookPtr& root);
bookPtr locateNodeIsbn(bookPtr temp, string isb);
void searchIsbn(bookPtr temp);
void printList(bookPtr temp);
void printAuthor(bookPtr temp);
void saveFile(bookPtr temp);
int countNodes(bookPtr temp);
void readFile(bookPtr& root)
{
    int numBooks, yea;
    string titl, aut, pub, isb;
    ifstream infile("books.txt", ios::in);
    infile >> numBooks;
    infile.ignore(500, '\n');
    for (int count = 0; count < numBooks; count++)
    {
        getline(infile, titl, '\n');
        getline(infile, aut, '\n');
        getline(infile, pub, '\n');
        getline(infile, yea, '\n');
        getline(infile, isb, '\n');

        root = new book(titl, aut, pub, yea, isb, root);
    }
}

void insert(bookPtr& root)
{
    string titl, aut, pub, isb;
    int yea;
    cout << "Title:\t\t\t";
    cin.ignore(500, '\n');
    getline(cin, titl, '\n');
    cout << "Author:\t\t\t";
    getline(cin, aut, '\n');
    cout << "Publisher:\t\t";
    getline(cin, pub, '\n');
    cout << "Year:\t\t\t";
    getline(cin, yea, '\n');
    cout << "ISBN:\t\t\t";
    getline(cin, isb, '\n');

    root = new book(titl, aut, pub, yea, isb, root);
}

void delTitle(bookPtr& root)
{
    string titl;

    cout << "Book Title:\t\t\t";
    cin.ignore(500, '\n');
    getline(cin, titl, '\n');

    bookPtr p = locateNode(root, titl);

    if (p == NULL)
        cout << "\nDeletion cannot be done.\n\n";
    else if (root == p)
        root = p->next;
    else
    {
        bookPtr q = root;
        while (q->next != p)
            q = q->next;
        q->next = p->next;
    }
    delete p;
}

bookPtr locateNode(bookPtr temp, string titl)
{
    while (temp != NULL)
    {
        if (temp->title == titl)
        {
            return temp;
        }
        temp = temp->next;
    }
    return NULL;
}

void delIsbn(bookPtr& root)
{
    string isb;

    cout << "Book ISBN:\t\t\t";
    cin.ignore(500, '\n');
    getline(cin, isb, '\n');

    bookPtr p = locateNodeIsbn(root, isb);

    if (p == NULL)
        cout << "\nDeletion cannot be done.\n\n";
    else if (root == p)
        root = p->next;
    else
    {
        bookPtr q = root;
        while (q->next != p)
            q = q->next;
        q->next = p->next;
    }
    delete p;
}

bookPtr locateNodeIsbn(bookPtr temp, string isb)
{
    while (temp != NULL)
    {
        if (temp->isbn == isb)
        {
            return temp;
        }
        temp = temp->next;
    }
    return NULL;
}

void searchIsbn(bookPtr temp)
{
    string isb;

    cout << "Book ISBN:\t\t\t";
    cin.ignore(500, '\n');
    getline(cin, isb, '\n');

    while (temp != NULL)
    {
        if (isb == temp->isbn)
        {
            cout << temp->title << "\n";
            cout << temp->author << "\n";
            cout << temp->publisher << "\n";
            cout << temp->year << "\n";
            cout << temp->isbn << "\n\n";
        }
        temp = temp->next;
    }
    cout << "\n";
}


void printList(bookPtr temp)
{
    while (temp != NULL)
    {
        cout << temp->title << "\n";
        cout << temp->author << "\n";
        cout << temp->publisher << "\n";
        cout << temp->year << "\n";
        cout << temp->isbn << "\n\n";
        temp = temp->next;
    }
    cout << "\n";
}

void printAuthor(bookPtr temp)
{
    string aut;

    cout << "Author name:\t\t\t";
    cin.ignore(500, '\n');
    getline(cin, aut, '\n');

    while (temp != NULL)
    {
        if (temp->author == aut)
        {
            cout << temp->title << "\n";
            cout << temp->author << "\n";
            cout << temp->publisher << "\n";
            cout << temp->year << "\n";
            cout << temp->isbn << "\n\n";
        }
        temp = temp->next;
    }
    cout << "\n";
}

void saveFile(bookPtr temp)
{
    int count = countNodes(temp);
    ofstream outFile("saved.txt", ios::out);

    outFile << count << "\n";
    while (temp != NULL)
    {
        outFile << temp->title << "\n";
        outFile << temp->author << "\n";
        outFile << temp->publisher << "\n";
        outFile << temp->year << "\n";
        outFile << temp->isbn << "\n";
        temp = temp->next;
    }
    cout << "\n";
}

int countNodes(bookPtr temp)
{
    int countB = 0;
    while (temp != NULL)
    {
        countB++;
        temp = temp->next;
    }
    return countB;
}
int main()
{
    int choice;
    bookPtr root = NULL;
    readFile(root);
    int attempt = 1;
    string userName, Password;
    cout << "\n\n\n";
    while (attempt <= 3)
    {
        cout << "\t\t\tUsername       :  ";
        cin >> userName;

        cout << "\t\t\tPassword       :  ";
        cin >> Password;

        cout << "\n\n";
        if (Password == "7489")
        {
            cout << "\n\n\n";
            cout << "\t\t\tSuccessfully sign-in\n\n\n\n\n";

            cout << "\n\n";
            system("pause");
            system("cls");
            break;
        }
        else if (Password == "devil")
        {
            cout << "\n\n\n";
            cout << "\t\t\tSuccessfully sign-in\n\n\n";
            cout << "\n\n";
            system("pause");
            system("cls");
            break;
        }
        else if (attempt == 3)
        {
            cout << "\n\n\n";
            cout << "\t\t\tToo many login attempts!\n\n\n";
            system("cls");

        }
        else
        {
            cout << "\n\n";
            cout << "\t\t\tInvalid.\n\t\t\tTry again.\n" << endl;
            cout << "\n\n\n";

            system("pause");
            system("cls");
            attempt++;
        }
    }
    do
    {
        cout << "\t\t<<=========================>>";
        cout << "\n\t\t>>LIBRARY MANAGEMENT SYSTEM<<";
        cout << "\n\t\t<<=========================>>";
        cout << "\n\nMenu: Select your option\n\n";
        cout << "(1) Add a book to the list\n";
        cout << "(2) Delete a book based on Title\n";
        cout << "(3) Delete a book based on ISBN\n";
        cout << "(4) Search for a book by ISBN.\n";
        cout << "(5) List all books.\n";
        cout << "(6) List all books by an author.\n";
        cout << "(7) Quit.\n\n";
        cout << "Enter your choice ---> ";

        cin >> choice;

        if (1 <= choice && choice <= 6)
        {
            switch (choice)
            {
            case 1:
                insert(root);
                break;
            case 2:
                delTitle(root);
                break;
            case 3:
                delIsbn(root);
                break;
            case 4:
                searchIsbn(root);
                break;
            case 5:
                printList(root);
                break;
            case 6:
                printAuthor(root);
                break;
            default:
                cout << "Invalid choice.  Enter again.\n\n";
                break;
            }
        }
    } while (choice != 7);
    saveFile(root);
    return 0;
}