#include "book.h"
book::book(string tempTitle, string tempAuthor, string tempPublisher, int tempYear, string tempIsbn, book* tempNext)
{
    title = tempTitle;
    author = tempAuthor;
    publisher = tempPublisher;
    year = tempYear;
    isbn = tempIsbn;
    next = tempNext;
}