#pragma once
#include<string>
using namespace std;
class book
{
public:
    string title;
    string author;
    string publisher;
    int year;
    string isbn;
    book* next;
    book(string, string, string, int, string, book*);
};